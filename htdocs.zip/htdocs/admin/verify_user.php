<?php
include('../includes/db.php');
$id = $_GET['id'];
mysqli_query($conn, "UPDATE users SET is_verified = 1 WHERE id = '$id'");
header("Location: dashboard.php");
?>