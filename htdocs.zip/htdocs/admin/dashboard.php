<?php 
session_start();
include('../includes/db.php');

// 1. Security Check
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

// 2. Statistics nikalna
$total_q = mysqli_query($conn, "SELECT count(*) as total FROM users");
$total_users = mysqli_fetch_assoc($total_q)['total'];

$premium_q = mysqli_query($conn, "SELECT count(*) as total FROM users WHERE is_premium = 1");
$premium_users = mysqli_fetch_assoc($premium_q)['total'];

// 3. User Details View Logic (Agar ID mangi jaye)
$view_user = null;
if (isset($_GET['view_id'])) {
    $v_id = mysqli_real_escape_string($conn, $_GET['view_id']);
    $v_res = mysqli_query($conn, "SELECT * FROM users WHERE id = '$v_id'");
    $view_user = mysqli_fetch_assoc($v_res);
}

// 4. Tamam users ka data nikalna list ke liye
$query = "SELECT * FROM users ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advance Master Admin Panel - SMB</title>
    <style>
        body {
            margin: 0; padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            background: linear-gradient(rgba(0,0,0,0.8), rgba(0,0,0,0.8)), url('../images/Sindh pic.jpg') no-repeat center center fixed;
            background-size: cover;
            min-height: 100vh;
            color: #333;
        }
        .container { max-width: 1300px; margin: 0 auto; padding: 30px 15px; }

        /* Glass Header */
        .header-panel {
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(15px);
            padding: 25px 40px;
            border-radius: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            margin-bottom: 30px;
            border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 15px 35px rgba(0,0,0,0.5);
        }
        .header-panel h1 { margin: 0; font-size: 24px; color: #ff9f43; letter-spacing: 2px; }

        /* Stats Cards */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: rgba(255,255,255,0.9); padding: 20px; border-radius: 15px; text-align: center; border-bottom: 5px solid #e67e22; }
        .stat-card h3 { margin: 0; color: #666; font-size: 14px; }
        .stat-card p { margin: 5px 0 0; font-size: 28px; font-weight: bold; color: #2c3e50; }

        /* Main Content Area */
        .content-card {
            background: rgba(255, 255, 255, 0.98);
            padding: 30px;
            border-radius: 25px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.4);
        }

        /* Modern Table */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table th { background: #2c3e50; color: #ff9f43; padding: 15px; text-align: left; font-size: 11px; text-transform: uppercase; }
        table td { padding: 15px; border-bottom: 1px solid #eee; font-size: 13px; }
        table tr:hover { background: #fdf2e9; }

        /* Badges & Buttons */
        .badge { padding: 4px 10px; border-radius: 4px; font-size: 10px; font-weight: bold; text-transform: uppercase; }
        .GOLD { background: #f1c40f; color: #000; }
        .SILVER { background: #bdc3c7; color: #2c3e50; }
        .FREE { background: #95a5a6; color: #fff; }

        .btn {
            display: inline-block; padding: 7px 12px; border-radius: 6px;
            text-decoration: none; font-size: 10px; font-weight: bold;
            color: white; margin-right: 3px; transition: 0.2s; border: none; cursor: pointer;
        }
        .btn-data { background: #3498db; }
        .btn-msg { background: #e67e22; }
        .btn-silver { background: #7f8c8d; }
        .btn-gold { background: #d4ac0d; }
        .btn-del { background: #c0392b; }
        .btn-cancel { background: #444; }

        /* Detail View Modal Background */
        .modal-overlay {
            position: fixed; top:0; left:0; width:100%; height:100%;
            background: rgba(0,0,0,0.8); display: flex; justify-content: center; align-items: center; z-index: 1000;
        }
        .modal-box {
            background: white; padding: 30px; border-radius: 20px; max-width: 600px; width: 90%;
            border-top: 10px solid #e67e22; max-height: 80vh; overflow-y: auto;
        }
    </style>
</head>
<body>

    <!-- 🔍 DETAIL VIEW MODAL (User Data) -->
    <?php if ($view_user): ?>
    <div class="modal-overlay">
        <div class="modal-box">
            <h2 style="color:#e67e22; margin-top:0;">User Profile Data 👁️</h2>
            <hr>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                <p><b>Pura Naam:</b> <?php echo $view_user['fullname']; ?></p>
                <p><b>WhatsApp:</b> <?php echo $view_user['phone']; ?></p>
                <p><b>Email:</b> <?php echo $view_user['email']; ?></p>
                <p><b>CNIC:</b> <?php echo $view_user['candidate_cnic'] ?: 'Not Provided'; ?></p>
                <p><b>Religion/Sect:</b> <?php echo $view_user['religion']; ?> / <?php echo $view_user['sect']; ?></p>
                <p><b>Zat (Caste):</b> <?php echo $view_user['caste']; ?></p>
                <p><b>Zila (District):</b> <?php echo $view_user['district']; ?></p>
                <p><b>Occupation:</b> <?php echo $view_user['occupation']; ?></p>
                <p><b>Education:</b> <?php echo $view_user['education']; ?></p>
            </div>
            <p><b>About/Bio:</b><br><?php echo $view_user['about_me']; ?></p>
            <div style="text-align: right; margin-top: 20px;">
                <a href="dashboard.php" style="background:#2c3e50; color:white; padding:10px 25px; border-radius:10px; text-decoration:none; font-weight:bold;">CLOSE WINDOW</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="container">
        
        <!-- Header -->
        <div class="header-panel">
            <div>
                <h1>MASTER ADMIN PANEL ★</h1>
                <p style="margin: 5px 0 0; font-size: 13px; color: #ccc;">Welcome, Sarang Ali! Controlling <b><?php echo $total_users; ?></b> Members.</p>
            </div>
            <a href="logout.php" class="btn-logout" style="background:#ff4757; color:white; padding:10px 25px; border-radius:50px; text-decoration:none; font-weight:bold;">LOGOUT EXIT</a>
        </div>

        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card"><h3>Total Registered</h3><p><?php echo $total_users; ?></p></div>
            <div class="stat-card"><h3>Premium Members</h3><p style="color:#f1c40f;"><?php echo $premium_users; ?></p></div>
            <div class="stat-card"><h3>Trial / Free Users</h3><p><?php echo ($total_users - $premium_users); ?></p></div>
        </div>

        <!-- Main User Card -->
        <div class="content-card">
            <h2 style="color: #2c3e50; margin-bottom: 20px; border-bottom: 2px solid #ff9f43; padding-bottom: 10px;">User Management Center</h2>
            
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Sr.#</th>
                            <th>Umeedwar Name</th>
                            <th>Joined Date</th>
                            <th>Current Plan</th>
                            <th>Expiry Status</th>
                            <th style="text-align: center;">Actions<!-- Admin Table ke andar ye field add karein -->
<form action="update_limit.php" method="POST" style="display:inline;">
    <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
    <input type="number" name="new_limit" value="<?php echo $row['requests_limit']; ?>" style="width:50px; padding:5px; border-radius:5px;">
    <button type="submit" style="background:#27ae60; color:#fff; border:none; padding:5px; cursor:pointer;">Update</button>
</form> (Membership Control)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sr = 1; 
                        while($row = mysqli_fetch_assoc($result)) { 
                            $plan = strtoupper($row['plan_type'] ?: 'FREE');
                            $joined_at = date('d M, Y', strtotime($row['created_at']));
                        ?>
                        <tr>
                            <td style="font-weight:bold; color:#777;"><?php echo $sr++; ?></td>
                            <td>
                                <strong><?php echo $row['fullname']; ?></strong><br>
                                <small style="color:#777;"><?php echo $row['email']; ?></small>
                            </td>
                            <td><small><?php echo $joined_at; ?></small></td>
                            <td><span class="badge <?php echo $plan; ?>"><?php echo $plan; ?></span></td>
                            <td>
                                <?php if($plan != 'FREE'): ?>
                                    <small style="color:red; font-weight:bold;">Exp: <?php echo $row['premium_expiry']; ?></small>
                                <?php else: ?>
                                    <small style="color:#999;">Standard User</small>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; white-space: nowrap;">
                                <!-- Advance Data View Link -->
                                <a href="dashboard.php?view_id=<?php echo $row['id']; ?>" class="btn btn-data">DATA 👁️</a>
                                
                                <a href="../connect.php?receiver_id=<?php echo $row['id']; ?>" class="btn btn-msg">MSG 💬</a>

                                <!-- Plan Upgrade Logic -->
                                <?php if($plan == 'FREE'): ?>
                                    <a href="make_premium.php?id=<?php echo $row['id']; ?>&set=Silver" class="btn btn-silver">+ SILVER</a>
                                    <a href="make_premium.php?id=<?php echo $row['id']; ?>&set=Gold" class="btn btn-gold">+ GOLD</a>
                                <?php else: ?>
                                    <a href="make_premium.php?id=<?php echo $row['id']; ?>&set=Free" class="btn btn-cancel" onclick="return confirm('Plan khatam karun?')">CANCEL ❌</a>
                                <?php endif; ?>

                                <a href="delete_user.php?id=<?php echo $row['id']; ?>" class="btn btn-del" onclick="return confirm('ATTENTION: Hamesha ke liye delete karun?')">REMOVE 🗑️</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</body>
</html>