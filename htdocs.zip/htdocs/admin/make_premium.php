<?php
// 1. Database aur Session
include('../includes/db.php');
session_start();

// 2. Security Check
if (!isset($_SESSION['admin_logged_in'])) {
    die("Zulm! Aap ko ye ijazat nahi hai.");
}

// 3. Logic Implementation
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);

    // Check karein ke user abhi Premium hai ya Free
    $check_query = mysqli_query($conn, "SELECT is_premium FROM users WHERE id = '$id'");
    $user_data = mysqli_fetch_assoc($check_query);

    if ($user_data) {
        if ($user_data['is_premium'] == 0) {
            // AGAR FREE HAI -> TO 15 DIN KE LIYE PREMIUM BANADO
            $expiry_date = date('Y-m-d', strtotime('+15 days')); // Aaj se 15 din baad
            
            $update_sql = "UPDATE users SET 
                            is_premium = 1, 
                            plan_type = 'Gold', 
                            requests_left = 999,
                            premium_expiry = '$expiry_date' 
                           WHERE id = '$id'";
            $msg = "User 15 din ke liye Premium ban gaya! ⭐ (Expires: $expiry_date)";
        } else {
            // AGAR PEHLE SE PREMIUM HAI -> TO WAPAS FREE KARDO (CANCEL OPTION)
            $update_sql = "UPDATE users SET 
                            is_premium = 0, 
                            plan_type = 'Free', 
                            requests_left = 0,
                            premium_expiry = NULL 
                           WHERE id = '$id'";
            $msg = "Premium Membership khatam kar di gayi.";
        }

        if (mysqli_query($conn, $update_sql)) {
            echo "<script>alert('$msg'); window.location='dashboard.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
} else {
    header("Location: dashboard.php");
}
?>