<?php
session_start();
session_destroy(); // Admin ki session khatam
header("Location: index.php"); // Wapas login page par bhej do
exit();
?>