<?php
include('../includes/db.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['user_id'];
    $limit = $_POST['new_limit'];
    mysqli_query($conn, "UPDATE users SET requests_limit = '$limit' WHERE id = '$id'");
    header("Location: dashboard.php");
}
?>