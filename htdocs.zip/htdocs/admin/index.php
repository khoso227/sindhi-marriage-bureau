<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Login - Sahil & Arman IT</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            /* Full Screen Bridal Background */
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), 
                        url('https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1974&auto=format&fit=crop') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center; /* Horizontally center */
            align-items: center;     /* Vertically center */
            overflow: hidden;
        }

        /* Glassmorphism Card */
        .login-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 50px 40px;
            border-radius: 30px;
            width: 100%;
            max-width: 380px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 50px rgba(0,0,0,0.6);
            text-align: center;
            color: white;
            box-sizing: border-box;
        }

        .icon-header {
            background: #e67e22;
            width: 70px; height: 70px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            margin: 0 auto 25px;
            font-size: 35px;
            box-shadow: 0 0 20px rgba(230, 126, 34, 0.6);
        }

        h1 { margin: 0; font-size: 26px; letter-spacing: 2px; color: #ff9f43; text-transform: uppercase; }
        p { font-size: 13px; margin-bottom: 35px; opacity: 0.8; letter-spacing: 1px; }

        /* Form Inputs */
        input {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 12px;
            border: none;
            outline: none;
            background: rgba(255, 255, 255, 0.9);
            color: #333;
            font-size: 16px;
            box-sizing: border-box;
            transition: 0.3s;
        }

        input:focus { background: #fff; box-shadow: 0 0 15px #e67e22; }

        /* Enter Button */
        button {
            width: 100%;
            padding: 16px;
            background: #e67e22;
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            text-transform: uppercase;
            box-shadow: 0 8px 15px rgba(230, 126, 34, 0.3);
        }

        button:hover { background: #d35400; transform: translateY(-3px); box-shadow: 0 12px 20px rgba(230, 126, 34, 0.5); }

        .back-link {
            margin-top: 30px;
            display: block;
            color: rgba(255, 255, 255, 0.6);
            text-decoration: none;
            font-size: 12px;
        }
        
        /* Sahil & Arman IT Branding */
        .it-brand {
            font-size: 10px;
            letter-spacing: 3px;
            color: #f1c40f;
            margin-top: 15px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>

    <div class="login-card">
        <div class="icon-header">🔑</div>
        <h1>MASTER LOGIN</h1>
        <p>Admin Control Panel • Secure Access</p>

        <form action="login_auth.php" method="POST" autocomplete="off">
            <input type="text" name="admin_id" placeholder="Admin Identity" required>
            <input type="password" name="admin_key" placeholder="Master Key" required>
            <button type="submit">ENTER DASHBOARD (داخل ٿيو)</button>
        </form>
        
        <div class="it-brand">Sahil & Arman IT Companies</div>
        <a href="../index.php" class="back-link">← Wapas Website Par Jao</a>
    </div>

</body>
</html>