<?php
session_start();

// 1. Aap ka Master Login Settings
$master_user = "sarang_admin";
$master_pass = "admin123";

// 2. Login Logic (Yeh backend ka kaam karega)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && (isset($_POST['admin_id']) || isset($_POST['admin_key']))) {
    
    // Naye unique names se data pakarna
    $input_user = isset($_POST['admin_id']) ? $_POST['admin_id'] : '';
    $input_pass = isset($_POST['admin_key']) ? $_POST['admin_key'] : '';

    if ($input_user === $master_user && $input_pass === $master_pass) {
        // Kamyabi: Session create karein
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $master_user;
        
        header("Location: dashboard.php");
        exit();
    } else {
        // Na-kaami: Ghalat password alert
        echo "<script>alert('Ghalat Password! Sirf Sarang Ali allowed hain.'); window.location='index.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Login - Sindhi Marriage Bureau</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            /* Background Image with Dark Overlay */
            background: linear-gradient(rgba(0,0,0,0.7), rgba(0,0,0,0.7)), url('../images/Sindh pic.jpg') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        /* Stylish Glass Effect Box */
        .login-box {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            padding: 40px;
            border-radius: 25px;
            width: 90%;
            max-width: 360px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 20px 50px rgba(0,0,0,0.6);
            text-align: center;
        }

        .icon-circle {
            background: #e67e22;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            box-shadow: 0 0 15px #e67e22;
            font-size: 30px;
        }

        h1 { 
            color: #e67e22; 
            margin: 0 0 5px 0; 
            font-size: 26px; 
            text-transform: uppercase; 
            letter-spacing: 2px; 
        }

        p { 
            color: white; 
            opacity: 0.8; 
            font-size: 13px; 
            margin-bottom: 30px; 
            text-transform: uppercase;
        }

        /* Input Fields Styling */
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 14px;
            margin-bottom: 20px;
            border-radius: 10px;
            border: none;
            outline: none;
            font-size: 15px;
            box-sizing: border-box;
            background: rgba(255, 255, 255, 0.9);
            transition: 0.3s;
        }

        input:focus { 
            background: #fff; 
            box-shadow: 0 0 15px rgba(230, 126, 34, 0.5); 
        }

        /* Action Button */
        button {
            width: 100%;
            padding: 15px;
            background: #e67e22;
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
            text-transform: uppercase;
            margin-top: 10px;
        }

        button:hover { 
            background: #d35400; 
            transform: scale(1.02); 
            box-shadow: 0 8px 20px rgba(230, 126, 34, 0.4); 
        }

        .back-link { 
            margin-top: 25px; 
            display: block; 
            color: rgba(255,255,255,0.6); 
            text-decoration: none; 
            font-size: 12px; 
            transition: 0.3s;
        }
        .back-link:hover { color: #fff; text-decoration: underline; }
    </style>
</head>
<body>

    <div class="login-box">
        <div class="icon-circle">👤</div>
        <h1>MASTER LOGIN</h1>
        <p>Admin Control Panel</p>

        <!-- FORM START (Ab ye isi file par data bhejega) -->
        <form action="index.php" method="POST" autocomplete="off">
            
            <!-- ANTI-AUTOFILL TRICK: Nakli hidden inputs -->
            <input type="text" style="display:none;" name="fake_user_field">
            <input type="password" style="display:none;" name="fake_pass_field">

            <!-- Real Input 1: Admin ID -->
            <input type="text" 
                   name="admin_id" 
                   placeholder="Admin Username" 
                   required 
                   readonly 
                   onfocus="this.removeAttribute('readonly');"
                   autocomplete="new-password">
            
            <!-- Real Input 2: Master Key -->
            <input type="password" 
                   name="admin_key" 
                   placeholder="Master Password" 
                   required 
                   readonly 
                   onfocus="this.removeAttribute('readonly');"
                   autocomplete="new-password">
            
            <button type="submit">ENTER DASHBOARD (داخل ٿيو)</button>
        </form>
        
        <a href="../index.php" class="back-link">← Wapas Website Par Jao</a>
    </div>

</body>
</html>