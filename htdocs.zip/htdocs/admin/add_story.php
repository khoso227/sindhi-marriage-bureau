<?php 
session_start();
include('../includes/db.php');
if (!isset($_SESSION['admin_logged_in'])) { header("Location: index.php"); exit(); }

// Story Save Karne ka Logic
if(isset($_POST['post_story'])){
    $name = mysqli_real_escape_string($conn, $_POST['couple_name']);
    $year = mysqli_real_escape_string($conn, $_POST['story_year']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    
    // Image Upload
    $img_name = $_FILES['story_img']['name'];
    $tmp_name = $_FILES['story_img']['tmp_name'];
    $path = "../uploads/stories/" . $img_name;
    
    if(move_uploaded_file($tmp_name, $path)){
        mysqli_query($conn, "INSERT INTO success_stories (couple_name, story_year, description, image) VALUES ('$name', '$year', '$desc', '$img_name')");
        echo "<script>alert('Story Post ho gayi!'); window.location='dashboard.php';</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Post Success Story</title>
    <style>
        body { font-family: sans-serif; background: #2c3e50; color: white; padding: 50px; }
        .box { max-width: 500px; margin: 0 auto; background: rgba(255,255,255,0.1); padding: 30px; border-radius: 15px; border: 1px solid #fff; }
        input, textarea { width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 5px; border: none; box-sizing: border-box; }
        button { width: 100%; padding: 15px; background: #e67e22; color: white; border: none; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Post Success Story ✍️</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="couple_name" placeholder="Couple Names (e.g. Ali & Dua)" required>
            <input type="text" name="story_year" placeholder="Year (e.g. 2024)" required>
            <textarea name="description" rows="5" placeholder="Inki kahani likhein..." required></textarea>
            <label>Couple Photo:</label>
            <input type="file" name="story_img" required>
            <button type="submit" name="post_story">POST STORY NOW</button>
        </form>
        <br><a href="dashboard.php" style="color: #ccc;">← Back to Dashboard</a>
    </div>
</body>
</html>