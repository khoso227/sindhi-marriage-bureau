<?php
include('../includes/db.php');
session_start();
if(!isset($_SESSION['admin_logged_in'])) { exit(); }

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM users WHERE id = '$id'");
header("Location: dashboard.php");
?>