<?php
include('../includes/db.php');
session_start();

// Check karein ke Admin logged in hai ya nahi
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}

if(isset($_GET['id'])){
    $id = $_GET['id'];
    // User ka status Approved kar do
    $sql = "UPDATE users SET status = 'Approved' WHERE id = '$id'";
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('User Approve ho gaya!'); window.location='dashboard.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>