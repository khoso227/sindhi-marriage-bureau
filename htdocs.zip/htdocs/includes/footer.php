<style>
    .master-footer {
        background: linear-gradient(rgba(10, 10, 10, 0.94), rgba(20, 20, 20, 0.97)), 
                    url('images/ajrak_bg.jpg');
        background-size: 250px;
        color: #ffffff;
        padding: 60px 20px;
        text-align: center;
        border-top: 5px solid #e67e22;
        margin-top: 50px;
    }
    .ai-hexagon {
        width: 70px; height: 70px;
        background: linear-gradient(45deg, #e67e22, #f1c40f);
        margin: 0 auto 20px;
        clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
        display: flex; align-items: center; justify-content: center;
        box-shadow: 0 0 25px rgba(230,126,34,0.5);
        animation: aiPulse 3s infinite ease-in-out;
    }
    .ai-hexagon span { color: #000; font-family: 'Arial Black'; font-size: 26px; font-weight: bold; }
    @keyframes aiPulse { 0% { transform: scale(1); } 50% { transform: scale(1.08); } 100% { transform: scale(1); } }
    .it-brand-footer { font-family: 'Impact', sans-serif; font-size: 28px; letter-spacing: 2px; color: #f1c40f; text-shadow: 0 2px 8px rgba(0,0,0,0.5); }
    .footer-bottom { font-size: 12px; color: #555; border-top: 1px solid #1a1a1a; padding-top: 25px; margin-top: 30px; }
</style>
<footer class="master-footer">
    <div class="ai-hexagon"><span>SA</span></div>
    <div style="color: #bbb; font-size: 14px; margin-bottom: 5px; text-transform: uppercase;">Secured & Managed By</div>
    <div class="it-brand-footer">SAHIL & ARMAN IT COMPANIES 🚀</div>
    <div style="font-size: 11px; color: #666; margin-top: 15px; letter-spacing: 4px;">AI CORE • WEB ARCHITECTURE • DATA SECURITY</div>
    <div class="footer-bottom">
        &copy; <?php echo date('Y'); ?> <b>Sindhi Marriage Bureau</b>. All Rights Reserved.<br>
        Developed with ❤️ by Sahil & Arman IT Team.
    </div>
</footer>
</body>
</html>