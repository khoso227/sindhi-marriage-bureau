<?php
// 1. Database Connection Settings
$host = "sql100.infinityfree.com"; 
$user = "if0_40746129";            
$pass = "khoso1234Admin"; 
$db_name = "if0_40746129_sindhi_marriage_db"; 

// Connection banana
$conn = mysqli_connect($host, $user, $pass, $db_name);

// Connection check karna
if (!$conn) {
    die("Database Connection failed: " . mysqli_connect_error());
}

// 2. MASTER SWEETALERT FUNCTION
// Is function ko aap poori website mein kahin bhi use kar sakte hain
function alertMe($icon, $title, $text, $url) {
    echo "
    <html>
    <head>
        <!-- SweetAlert2 CDN Library -->
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
    </head>
    <body style='background:#fdf2e9; font-family: sans-serif;'>
        <script>
            Swal.fire({
                icon: '$icon',
                title: '$title',
                text: '$text',
                confirmButtonColor: '#e67e22',
                confirmButtonText: 'Theek Hai'
            }).then((result) => {
                window.location = '$url';
            });
        </script>
    </body>
    </html>";
    exit(); // Code ko yahin rokne ke liye
}
?>