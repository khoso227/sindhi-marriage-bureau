<?php
if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
}

// Language set karne ki logic
if (isset($_GET['set_lang'])) {
    $allowed_langs = ['en', 'sd'];
    if (in_array($_GET['set_lang'], $allowed_langs)) {
        $_SESSION['lang'] = $_GET['set_lang'];
    }
    // Page refresh logic
    $current_url = strtok($_SERVER['REQUEST_URI'], '?');
    header("Location: " . $current_url);
    exit();
}

// Default language
if (!isset($_SESSION['lang'])) { 
    $_SESSION['lang'] = 'en'; 
}

$current_language = $_SESSION['lang'];

// Translation Data
$all_text = [
    'en' => [
        'home' => 'Home', 
        'login' => 'Login', 
        'register' => 'Register',
        'welcome' => 'Sindhi Marriage Bureau', 
        'slogan' => 'True Match, True Identity',
        'dir' => 'ltr', 
        'align' => 'left'
    ],
    'sd' => [
        'home' => 'گھر', 
        'login' => 'لاگ ان', 
        'register' => 'رجسٽريشن',
        'welcome' => 'سنڌي ميريج بيورو', 
        'slogan' => 'سچو رشتو، سڃاڻپ',
        'dir' => 'rtl', 
        'align' => 'right'
    ]
];

// Final Variable jo poori website par use hogi
$L = $all_text[$current_language];