<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

if(isset($_GET['lang'])) { $_SESSION['lang'] = $_GET['lang']; }
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'en';

$menu_text = [
    'en' => ['home'=>'Home', 'login'=>'Login', 'reg'=>'Register', 'logout'=>'Logout', 'dash'=>'Dashboard', 'search'=>'Search'],
    'sd' => ['home'=>'گھر', 'login'=>'داخل ٿيو', 'reg'=>'رجسٽر ٿيو', 'logout'=>'باهر نڪرو', 'dash'=>'ڊيش بورڊ', 'search'=>'ڳولا']
];
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sindhi Marriage Bureau - Sahil & Arman IT</title>
    <style>
        body { margin:0; font-family: 'Segoe UI', Tahoma, sans-serif; background: #fdf2e9; color: #333; }
        
        /* Navbar with Ajrak Pattern */
        nav { 
            background: linear-gradient(rgba(230, 126, 34, 0.8), rgba(139, 0, 0, 0.9)), 
                        url('https://t4.ftcdn.net/jpg/04/13/41/58/360_F_413415814_oD2P08r1mIskYh9MmqvQ6E6UvI8vIqYm.jpg'); 
            background-size: 150px;
            padding: 15px 30px; 
            color: white; 
            display: flex; 
            justify-content: space-between; 
            align-items: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            position: sticky; top: 0; z-index: 1000;
            border-bottom: 3px solid #f1c40f;
        }

        .it-sign-top {
            background: #111;
            color: #f1c40f;
            padding: 6px 15px;
            border: 2px double #f1c40f;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-weight: bold;
            font-size: 12px;
            text-decoration: none;
            text-transform: uppercase;
        }

        .nav-links a { color: white; text-decoration: none; margin-left: 18px; font-weight: bold; font-size: 15px; transition: 0.3s; }
        .nav-links a:hover { color: #f1c40f; }

        .lang-switcher {
            background: rgba(0,0,0,0.4);
            color: white; text-decoration: none;
            padding: 5px 12px; border-radius: 20px; font-size: 11px; margin-left: 15px;
            border: 1px solid rgba(255,255,255,0.3);
        }

        @media (max-width: 768px) {
            nav { flex-direction: column; gap: 10px; text-align: center; }
        }
    </style>
</head>
<body>
<nav>
    <a href="index.php" class="it-sign-top">Sahil & Arman IT Companies 💻</a>
    <div class="nav-links">
        <a href="index.php"><?php echo $menu_text[$lang]['home']; ?></a>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="dashboard.php"><?php echo $menu_text[$lang]['dash']; ?></a>
            <a href="logout.php" style="color:#f1c40f;"><?php echo $menu_text[$lang]['logout']; ?></a>
        <?php else: ?>
            <a href="login.php"><?php echo $menu_text[$lang]['login']; ?></a>
            <a href="register.php"><?php echo $menu_text[$lang]['reg']; ?></a>
        <?php endif; ?>
        <a href="?lang=<?php echo ($lang=='en')?'sd':'en'; ?>" class="lang-switcher">
            <?php echo ($lang=='en')?'سنڌي':'English'; ?>
        </a>
    </div>
</nav>