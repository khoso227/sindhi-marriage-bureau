<?php
include('../includes/db.php');

if (isset($_POST['register_btn'])) {
    // Form se data lena (Make sure names match your register.php)
    $fullname = $_POST['fullname'];
    $email    = $_POST['email'];
    $password = $_POST['password'];
    $gender   = $_POST['gender'];
    $caste    = $_POST['caste'];
    $district = $_POST['district'];
    $guardian = $_POST['guardian_name'];
    $relation = $_POST['guardian_relation'];
    $cnic     = $_POST['cnic'];
    $education = $_POST['education'];

    // Nayi SQL Query jo nayi table ke mutabiq hai
    $sql = "INSERT INTO users (fullname, email, password, gender, caste, district, guardian_name, guardian_relation, cnic_number, education_level) 
            VALUES ('$fullname', '$email', '$password', '$gender', '$caste', '$district', '$guardian', '$relation', '$cnic', '$education')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Mubarak ho! Profile ban gayi hai.'); window.location='../login.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>