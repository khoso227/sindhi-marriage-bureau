<?php
session_start();
include('../includes/db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $u_id = $_SESSION['user_id']; // Step 1 se mili hui ID

    $gn    = mysqli_real_escape_string($conn, $_POST['guardian_name']);
    $rel   = mysqli_real_escape_string($conn, $_POST['relation']);
    $age   = mysqli_real_escape_string($conn, $_POST['age']);
    $gen   = mysqli_real_escape_string($conn, $_POST['gender']);
    $mzhb  = mysqli_real_escape_string($conn, $_POST['religion']);
    $sect  = mysqli_real_escape_string($conn, $_POST['sect']);
    $caste = mysqli_real_escape_string($conn, $_POST['caste']);
    $div   = mysqli_real_escape_string($conn, $_POST['division']);
    $dist  = mysqli_real_escape_string($conn, $_POST['district']);
    $teh   = mysqli_real_escape_string($conn, $_POST['tehsil']);

    $sql = "UPDATE users SET 
            guardian_name='$gn', relation='$rel', age='$age', gender='$gen', 
            religion='$mzhb', sect='$sect', caste='$caste', 
            division='$div', district='$dist', tehsil='$teh' 
            WHERE id='$u_id'";

    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Mubarak ho! Profile mukammal ho gayi.'); window.location='../dashboard.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>if(empty($_POST['fullname']) || empty($_POST['phone']) || empty($_POST['candidate_cnic'])) {
    echo "<script>alert('Ghalat! Saari malomat bharna lazmi hai.'); window.history.back();</script>";
    exit();
}