<?php
session_start();
include('../includes/db.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Check if email already exists
    $check = mysqli_query($conn, "SELECT id FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        alertMe('warning', 'Pehle se Maujood!', 'Yeh Email pehle se register hai.', '../register.php');
    }

    // Step 1: Basic info insert karna
    $sql = "INSERT INTO users (fullname, email, password, created_at, is_premium) 
            VALUES ('$fullname', '$email', '$password', NOW(), 0)";

    if (mysqli_query($conn, $sql)) {
        // Auto-login karke Step 2 par bhejna
        $_SESSION['user_id'] = mysqli_insert_id($conn);
        $_SESSION['user_fullname'] = $fullname;

        // Success SweetAlert
        alertMe('success', 'Mubarak Ho!', 'Account ban gaya! Ab apni profile mukammal karein.', '../complete_profile.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: ../register.php");
}
?>