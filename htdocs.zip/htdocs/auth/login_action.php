 <?php
session_start();
include('../includes/db.php');

if (isset($_POST['login_btn'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user_data = mysqli_fetch_assoc($result);
        $_SESSION['user_id'] = $user_data['id'];
        $_SESSION['user_name'] = $user_data['fullname'];

        header("Location: ../dashboard.php");
    } else {
        echo "<script>alert('Ghalat Email ya Password!'); window.location='../login.php';</script>";
    }
}
header("Location: ../login.php?error=1");
exit();