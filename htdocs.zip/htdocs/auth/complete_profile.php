<?php 
include('includes/db.php');
include('includes/header.php'); 
if(!isset($_SESSION['user_id'])) { header("Location: register.php"); exit(); }
?>

<div style="background: #f4f4f4; padding: 50px 10px; min-height: 100vh; font-family: Arial;">
    <div style="max-width: 900px; margin: 0 auto; background: white; padding: 40px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border-top: 8px solid #e67e22;">
        
        <div style="text-align: center; margin-bottom: 40px;">
            <h2 style="color: #e67e22;">STEP 2: MUKAMMAL MALOMAT (مڪمل معلومات)</h2>
            <p>Mubarak ho! Account ban gaya. Ab rishtay ke liye ye malomat bharein.</p>
        </div>

        <form action="auth/finish_profile.php" method="POST">
            
            <!-- 1. Guardian & Personal -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <input type="text" name="guardian_name" placeholder="Sarparast ka Naam" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                <select name="relation" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                    <option value="Walid">Walid (Father) / پيءُ</option>
                    <option value="Walida">Walida (Mother) / ماءُ</option>
                    <option value="Aziz">Aziz / مائٽ</option>
                    <option value="Self">Self / پاڻ</option>
                </select>
                <input type="number" name="age" placeholder="Age (عمر)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                <select name="gender" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                    <option value="Mard">Mard / گھوٽ</option>
                    <option value="Khatoon">Khatoon / ڪنوار</option>
                </select>
            </div>

            <!-- 2. Religion & Caste (MANUAL ENTRY - Jaisa dost ne kaha) -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <input type="text" name="religion" placeholder="Mazhab (Religion)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                <input type="text" name="sect" placeholder="Firqa (Sect)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
            </div>
            <input type="text" name="caste" placeholder="Apni asli Zat (Caste) likhein" required style="width: 97%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin-bottom: 25px;">

            <!-- 3. Location (MANUAL ENTRY) -->
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin-bottom: 30px;">
                <input type="text" name="division" placeholder="Range (ڊويزن)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                <input type="text" name="district" placeholder="Zila (ضلعو)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                <input type="text" name="tehsil" placeholder="Tehsil (تحصيل)" required style="padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
            </div>

            <button type="submit" style="width: 100%; padding: 18px; background: #2c3e50; color: white; border: none; border-radius: 12px; font-weight: bold; font-size: 20px; cursor: pointer;">
                PROFILE MUKAMMAL KAREIN →
            </button>
        </form>
    </div>
</div>

<?php include('includes/footer.php'); ?>