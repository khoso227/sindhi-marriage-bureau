<?php
include('includes/db.php');
session_start();

if (isset($_POST['upload_btn'])) {
    $my_id = $_SESSION['user_id'];
    
    $file_name = $_FILES['profile_pic']['name'];
    $file_tmp = $_FILES['profile_pic']['tmp_name'];
    
    // File ka naya naam rakhein (taake duplicate na ho)
    $new_file_name = "user_" . $my_id . "_" . time() . ".jpg";
    $upload_path = "uploads/" . $new_file_name;

    // File ko "uploads" folder mein move karein
    if (move_uploaded_file($file_tmp, $upload_path)) {
        // Database mein photo ka naam save karein
        mysqli_query($conn, "UPDATE users SET image = '$new_file_name' WHERE id = '$my_id'");
        echo "<script>alert('Photo upload ho gayi hai!'); window.location='edit_profile.php';</script>";
    } else {
        echo "<script>alert('Maafi chahte hain, upload nahi ho saki. Folder permissions check karein.'); window.location='edit_profile.php';</script>";
    }
}
?>