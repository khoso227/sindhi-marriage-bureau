<?php 
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$my_id = $_SESSION['user_id'];

// User ka data nikalna
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id = '$my_id'"));
$current_img = (!empty($user['image'])) ? "uploads/".$user['image'] : "images/default_user.png";
?>

<div style="max-width: 500px; margin: 30px auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0,0,0,0.1); text-align: center;">
    
    <h2 style="color: #e67e22;">Meri Profile Edit Karein</h2>
    
    <!-- Current Photo Display -->
    <div style="margin-bottom: 20px;">
        <img src="<?php echo $current_img; ?>" style="width: 150px; height: 150px; border-radius: 50%; border: 5px solid #e67e22; object-fit: cover;">
    </div>

    <!-- Upload Form -->
    <form action="upload_action.php" method="POST" enctype="multipart/form-data" style="background: #fdf2e9; padding: 20px; border-radius: 10px;">
        <label style="font-weight: bold; display: block; margin-bottom: 10px;">Nayi Tasveer Chunein:</label>
        <input type="file" name="profile_pic" accept="image/*" required style="margin-bottom: 15px;">
        
        <button type="submit" name="upload_btn" style="width: 100%; padding: 12px; background: #e67e22; color: white; border: none; border-radius: 5px; font-weight: bold; cursor: pointer;">
            PHOTO UPLOAD KAREIN
        </button>
    </form>

    <div style="margin-top: 20px;">
        <a href="dashboard.php" style="color: #666; text-decoration: none;">← Wapas Dashboard</a>
    </div>
</div>

<?php include('includes/footer.php'); ?>